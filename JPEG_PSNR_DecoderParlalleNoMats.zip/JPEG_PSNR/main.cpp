
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>

#include <math.h>


#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <cstdio>
#include <memory>
#include <stdexcept>
#include <string>
#include <array>

#include <fstream>
#include <regex>

#include "jpegdecoder.h"
#include "TypeDef.h"
#include "jpegencoderMultipleQF.h"

// for time
#include <chrono>


#define IS_PARALLEL 1

using namespace std;
using namespace cv;



double getPSNR3(const Mat& I1, const Mat& I2)
{
    Mat s1;
    absdiff(I1, I2, s1);       // |I1 - I2|
    s1.convertTo(s1, CV_32F);  // cannot make a square on 8 bits
    s1 = s1.mul(s1);           // |I1 - I2|^2
    
    Scalar s = sum(s1);        // sum elements per channel
    
    double sse = s.val[0] + s.val[1] + s.val[2]; // sum channels
    
    if( sse <= 1e-10) // for small values return zero
        return 0;
    else
    {
        double mse  = sse / (double)(I1.channels() * I1.total());
        double psnr = 10.0 * log10((255 * 255) / mse);
        return psnr;
    }
}

#if IS_PARALLEL

int main(int argc, char** argv) {
    
    // Input file:
    //    std::string f1_yuv = argv[1];
    std::string f1_yuv = "/Users/ahamsala/Documents/validation_original/shard-0/1/ILSVRC2012_val_00000001.JPEG";
    
    // Input file:
    //    std::string f2_yuv = argv[2];
    std::string f2_yuv = "/Volumes/MULTICOM-104/validation_generated_QF/shard-0/1/ILSVRC2012_val_00000001-QF-0.JPEG";
    // Output file
    
    // first and Second Image
    jpeg_decoder Org_YUV (f1_yuv);
    jpeg_decoder QF_YUV  (f2_yuv);
    

    // Declare the needed datastructures for Y, Cb, Cr:
    vector<vector<unsigned char>> ORG_vec_Y, ORG_vec_Cb, ORG_vec_Cr;
    vector<vector<unsigned char>> QF_vec_Y, QF_vec_Cb, QF_vec_Cr;
    double psnr, psnr_Y, psnr_Cb, psnr_Cr;
    double mssim, mssim_Y, mssim_Cb, mssim_Cr;
    mssim_Y = mssim_Cb = mssim_Cr = 0;
    psnr_Y  = psnr_Cb  = psnr_Cr = 0;

    
    int width  = Org_YUV.upscale_width;
    int height = Org_YUV.upscale_height;
    int width2  = QF_YUV.upscale_width;
    int height2 = QF_YUV.upscale_height;
    int nComponents = Org_YUV.numberOfComponents;
    int nComponents2 = QF_YUV.numberOfComponents;
    
    assert(width  == width2);
    assert(height == height2);
    assert(nComponents == nComponents2);
    
    // Create the mats
    cv::Mat ORG_mat_Y, ORG_mat_Cb, ORG_mat_Cr;
    cv::Mat QF_mat_Y, QF_mat_Cb, QF_mat_Cr;
    
    
    // Fill the datastructures with values
    ORG_vec_Y.resize(height, vector<unsigned char> (width, 0));
    ORG_vec_Y = Arr2Vec(Org_YUV.m_YPicture_buffer, width, height);
    ORG_mat_Y = vec2mat(ORG_vec_Y);
    
    QF_vec_Y.resize(height, vector<unsigned char> (width, 0));
    QF_vec_Y = Arr2Vec(QF_YUV.m_YPicture_buffer, width, height);
    QF_mat_Y = vec2mat(QF_vec_Y);
    
    
    psnr_Y = getPSNR(ORG_mat_Y, QF_mat_Y, width, height);
    Scalar final_mssim = getMSSIM(ORG_mat_Y, QF_mat_Y);
    mssim_Y = final_mssim[0];
    
    
    if (nComponents > 1)
    {
        // Org:
        // Cb component
        ORG_vec_Cb.resize(height, vector<unsigned char> (width, 0));
        ORG_vec_Cb = Arr2Vec(Org_YUV.m_CbPicture_buffer, width, height);
        ORG_mat_Cb = vec2mat(ORG_vec_Cb);
        

        // Cr component
        ORG_vec_Cr.resize(height, vector<unsigned char> (width, 0));
        ORG_vec_Cr = Arr2Vec(Org_YUV.m_CrPicture_buffer, width, height);
        ORG_mat_Cr = vec2mat(ORG_vec_Cr);

        // QF:
        // Cb component
        QF_vec_Cb.resize(height, vector<unsigned char> (width, 0));
        QF_vec_Cb = Arr2Vec(QF_YUV.m_CbPicture_buffer, width, height);
        QF_mat_Cb= vec2mat(QF_vec_Cb);


        // Cr component
        QF_vec_Cr.resize(height, vector<unsigned char> (width, 0));
        QF_vec_Cr = Arr2Vec(QF_YUV.m_CrPicture_buffer, width, height);
        QF_mat_Cr = vec2mat(QF_vec_Cr);


//         Calculate the quality metrics
        psnr_Cb = getPSNR(ORG_mat_Cb, QF_mat_Cb, width, height);
        psnr_Cr = getPSNR(ORG_mat_Cr, QF_mat_Cr, width, height);

        Scalar final_mssim = getMSSIM(ORG_mat_Cb, QF_mat_Cb);
        mssim_Cb = final_mssim[0];
        final_mssim = getMSSIM(ORG_mat_Cr, QF_mat_Cr);
        mssim_Cr = final_mssim[0];
    }
    
    mssim = (6*mssim_Y + mssim_Cb + mssim_Cr)/8;
    psnr  =(6*psnr_Y + psnr_Cb + psnr_Cr)/8;
    
    reportMetrics(psnr_Y, psnr_Cb, psnr_Cr);
    reportMetrics(mssim_Y, mssim_Cb, mssim_Cr);
    
    
//    std::string filename = "/Volumes/MULTICOM-104/validation_original/shard-0/1/ILSVRC2012_val_00000001.JPEG";
//    std::string enc_path_to_files = "/Volumes/MULTICOM-104/validation_generated_QF";
    std::string filename = "/Users/ahamsala/Documents/validation_original/shard-0/1/ILSVRC2012_val_00000001.JPEG";
    std::string enc_path_to_files = "/Users/ahamsala/Documents/validation_generated_QF";
    std::string txt_path = "/Volumes/MULTICOM-104/validation_generated_QF_TXT_1";
    runEncoderWithMultipleQF(filename, enc_path_to_files, txt_path);
    
    return 0;
    
}

#else

int main(int argc, char** argv) {
    
    // Input file:
    //    std::string f1_yuv = argv[1];
    std::string f1_yuv = "/Users/ahamsala/Documents/validation_original/shard-0/1/ILSVRC2012_val_00000001.JPEG";
    
    // Input file:
    //    std::string f2_yuv = argv[2];
    std::string f2_yuv = "/Volumes/MULTICOM-104/validation_generated_QF/shard-0/1/ILSVRC2012_val_00000001-QF-0.JPEG";
    // Output file
    //    std::string output_file = ;
    
    // first and Second Image
    jpeg_decoder Org_YUV (f1_yuv);
    jpeg_decoder QF_YUV (f2_yuv);
    
    
    // Declare the needed datastructures for Y, Cb, Cr:
    vector<vector<unsigned char>> ORG_vec_Y, ORG_vec_Cb, ORG_vec_Cr;
    vector<vector<unsigned char>> QF_vec_Y, QF_vec_Cb, QF_vec_Cr;
    double psnr, psnr_Y, psnr_Cb, psnr_Cr;
    double mssim, mssim_Y, mssim_Cb, mssim_Cr;
    mssim_Y = mssim_Cb = mssim_Cr = 0;
    psnr_Y  = psnr_Cb  = psnr_Cr = 0;
    
    
    int width  = Org_YUV.upscale_width;
    int height = Org_YUV.upscale_height;
    int width2  = QF_YUV.upscale_width;
    int height2 = QF_YUV.upscale_height;
    int nComponents = Org_YUV.numberOfComponents;
    int nComponents2 = QF_YUV.numberOfComponents;
    
    assert(width  == width2);
    assert(height == height2);
    assert(nComponents == nComponents2);
    
    // Create the mats
    cv::Mat ORG_mat_Y, ORG_mat_Cb, ORG_mat_Cr;
    cv::Mat QF_mat_Y, QF_mat_Cb, QF_mat_Cr;
    
    
    // Fill the datastructures with values
    ORG_vec_Y.resize(height, vector<unsigned char> (width, 0));
    ORG_vec_Y = Arr2Vec(Org_YUV.m_YPicture_buffer, width, height);
    ORG_mat_Y = vec2mat(ORG_vec_Y);
    
    QF_vec_Y.resize(height, vector<unsigned char> (width, 0));
    QF_vec_Y = Arr2Vec(QF_YUV.m_YPicture_buffer, width, height);
    QF_mat_Y = vec2mat(QF_vec_Y);
    
    
    psnr_Y = getPSNR(ORG_mat_Y, QF_mat_Y, width, height);
    Scalar final_mssim = getMSSIM(ORG_mat_Y, QF_mat_Y);
    mssim_Y = final_mssim[0];
    
    
    if (nComponents > 1)
    {
        // Org:
        // Cb component
        ORG_vec_Cb.resize(height, vector<unsigned char> (width, 0));
        ORG_vec_Cb = Arr2Vec(Org_YUV.m_CbPicture_buffer, width, height);
        ORG_mat_Cb = vec2mat(ORG_vec_Cb);
        
        
        // Cr component
        ORG_vec_Cr.resize(height, vector<unsigned char> (width, 0));
        ORG_vec_Cr = Arr2Vec(Org_YUV.m_CrPicture_buffer, width, height);
        ORG_mat_Cr = vec2mat(ORG_vec_Cr);
        
        // QF:
        // Cb component
        QF_vec_Cb.resize(height, vector<unsigned char> (width, 0));
        QF_vec_Cb = Arr2Vec(QF_YUV.m_CbPicture_buffer, width, height);
        QF_mat_Cb= vec2mat(QF_vec_Cb);
        
        
        // Cr component
        QF_vec_Cr.resize(height, vector<unsigned char> (width, 0));
        QF_vec_Cr = Arr2Vec(QF_YUV.m_CrPicture_buffer, width, height);
        QF_mat_Cr = vec2mat(QF_vec_Cr);
        
        
        //         Calculate the quality metrics
        psnr_Cb = getPSNR(ORG_mat_Cb, QF_mat_Cb, width, height);
        psnr_Cr = getPSNR(ORG_mat_Cr, QF_mat_Cr, width, height);
        
        Scalar final_mssim = getMSSIM(ORG_mat_Cb, QF_mat_Cb);
        mssim_Cb = final_mssim[0];
        final_mssim = getMSSIM(ORG_mat_Cr, QF_mat_Cr);
        mssim_Cr = final_mssim[0];
    }
    
    mssim = (6*mssim_Y + mssim_Cb + mssim_Cr)/8;
    psnr  =(6*psnr_Y + psnr_Cb + psnr_Cr)/8;
    
    reportMetrics(psnr_Y, psnr_Cb, psnr_Cr);
    reportMetrics(mssim_Y, mssim_Cb, mssim_Cr);
    
    
    
    return 0;
    
}
#endif
