
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>

#include <math.h>


#include <opencv2/opencv.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <cstdio>
#include <memory>
#include <stdexcept>
#include <string>
#include <array>

#include <fstream>
#include <regex>

#include "jpegdecoder.h"
#include "TypeDef.h"
#include "jpegencoderMultipleQF.h"

using namespace std;
using namespace cv;



double getPSNR3(const Mat& I1, const Mat& I2)
{
    Mat s1;
    absdiff(I1, I2, s1);       // |I1 - I2|
    s1.convertTo(s1, CV_32F);  // cannot make a square on 8 bits
    s1 = s1.mul(s1);           // |I1 - I2|^2
    
    Scalar s = sum(s1);        // sum elements per channel
    
    double sse = s.val[0] + s.val[1] + s.val[2]; // sum channels
    
    if( sse <= 1e-10) // for small values return zero
        return 0;
    else
    {
        double mse  = sse / (double)(I1.channels() * I1.total());
        double psnr = 10.0 * log10((255 * 255) / mse);
        return psnr;
    }
}

void reportMetrics(double x, double y, double z)
{
    cout << "X: " << x << "\nY: " << y << "\nZ: " << z << endl;
}


int main(int argc, char** argv) {
    
    
    double mssim_Y,mssim_Cb,mssim_Cr,mssim;
    double psnr_Y,psnr_Cb,psnr_Cr,psnr;
    mssim_Cb = 0;
    psnr_Cb = 0;
    mssim_Cr = 0;
    psnr_Cr = 0;
    double cosine_idct[8][8];
    const float PI = 3.14159265358979323846264338327950288419716939937510582097494459230781640628f;
    const double inv16 = 1.0 / 16.0;
    
    for (int i = 0; i < 8; i++)
    {
        for (int j = 0; j < 8; j++)
        {
            cosine_idct[j][i] = cosf( (2.0 * i + 1) * j * PI * inv16 );
        }
    }
  
    // Input file:
    //    std::string f1_yuv = argv[1];
    std::string f1_yuv = "/Users/ahamsala/Documents/validation_original/shard-0/1/ILSVRC2012_val_00000001.JPEG";
    
    // Input file:
    //    std::string f2_yuv = argv[2];
    std::string f2_yuv = "/Volumes/MULTICOM-104/validation_generated_QF/shard-0/1/ILSVRC2012_val_00000001-QF-0.JPEG";
    // Output file
    //    std::string output_file = ;
  
    // first and Second Image
    jpeg_decoder Org_YUV (f1_yuv, cosine_idct);
    jpeg_decoder QF_YUV (f2_yuv, cosine_idct);
    
    
    // Y Compenent
    // Convert Picture buffer into vector
    vector<vector<unsigned char>> ORG_vec_Y, ORG_vec_Cb, ORG_vec_Cr;
    cv::Mat ORG_mat_Cr_420, ORG_mat_Cb_420;
    ORG_vec_Y.resize(Org_YUV.jpegImageHeight, vector<unsigned char> (Org_YUV.jpegImageWidth, 0));
    ORG_vec_Y = Arr2Vec(Org_YUV.m_YPicture_buffer, Org_YUV.jpegImageWidth, Org_YUV.jpegImageHeight);
    cv::Mat ORG_mat_Y = vec2mat(ORG_vec_Y);
    
    // Convert Picture buffer into vector
    vector<vector<unsigned char>> QF_vec_Y, QF_vec_Cb, QF_vec_Cr;
    cv::Mat QF_mat_Cr_420, QF_mat_Cb_420;
    QF_vec_Y.resize(QF_YUV.jpegImageHeight, vector<unsigned char> (QF_YUV.jpegImageWidth, 0));
    QF_vec_Y = Arr2Vec(QF_YUV.m_YPicture_buffer,QF_YUV.jpegImageWidth, QF_YUV.jpegImageHeight);
    
    cv::Mat ORG_mat_Cb, ORG_mat_Cr;
    
    cv::Mat QF_mat_Y = vec2mat(QF_vec_Y);
    // Calculate the quality metrics
    psnr_Y = getPSNR(ORG_mat_Y, QF_mat_Y, QF_YUV.jpegImageWidth, QF_YUV.jpegImageHeight);
    Scalar final_mssim = getMSSIM(ORG_mat_Y, QF_mat_Y);
    mssim_Y = final_mssim[0];
    
    cout << "HELLO " << endl;
    
    if (Org_YUV.components.size() > 1)
    {
        // Cb component
        ORG_vec_Cb.resize(Org_YUV.jpegImageHeight, vector<unsigned char> (Org_YUV.jpegImageWidth, 0));
        ORG_vec_Cb = Arr2Vec(Org_YUV.m_CbPicture_buffer, Org_YUV.jpegImageWidth, Org_YUV.jpegImageHeight);
        ORG_mat_Cb = vec2mat(ORG_vec_Cb);
        
        cout << "HELLO2 " << endl;
        
        // Cr component
        ORG_vec_Cr.resize(Org_YUV.jpegImageHeight, vector<unsigned char> (Org_YUV.jpegImageWidth, 0));
        ORG_vec_Cr = Arr2Vec(Org_YUV.m_CrPicture_buffer,Org_YUV.jpegImageWidth, Org_YUV.jpegImageHeight);
        ORG_mat_Cr= vec2mat(ORG_vec_Cr);
        
        cout << "HELLO3 " << endl;
    }
    if (Org_YUV.components.size() > 1)
    {
        
        cout << "HELLO4 " << endl;
        // Cb component
        QF_vec_Cb.resize(QF_YUV.jpegImageHeight, vector<unsigned char> (QF_YUV.jpegImageWidth, 0));
        QF_vec_Cb = Arr2Vec(QF_YUV.m_CbPicture_buffer,QF_YUV.jpegImageWidth, QF_YUV.jpegImageHeight);
        cv::Mat QF_mat_Cb= vec2mat(QF_vec_Cb);
        
        cout << "HELLO5 " << endl;
        
        // Cr component
        QF_vec_Cr.resize(QF_YUV.jpegImageHeight, vector<unsigned char> (QF_YUV.jpegImageWidth, 0));
        
        cout << "HELLO5-1 " << endl;
        QF_vec_Cr = Arr2Vec(QF_YUV.m_CrPicture_buffer,QF_YUV.jpegImageWidth, QF_YUV.jpegImageHeight);
        cout << "HELLO5-2 " << endl;
        cv::Mat QF_mat_Cr= vec2mat(QF_vec_Cr);
        cout << "HELLO5-3 " << endl;
        cout << "HELLO6 " << endl;
        
        // Calculate the quality metrics
        psnr_Cb = getPSNR(ORG_mat_Cb, QF_mat_Cb, QF_YUV.jpegImageWidth, QF_YUV.jpegImageHeight);
        
        cout << "HELLO6-1 " << endl;
        psnr_Cr = getPSNR(ORG_mat_Cr, QF_mat_Cr, QF_YUV.jpegImageWidth, QF_YUV.jpegImageHeight);
        
        cout << "HELLO6-2 " << endl;
        Scalar final_mssim = getMSSIM(ORG_mat_Cb, QF_mat_Cb);
        
        cout << "HELLO6-3 " << endl;
        mssim_Cb = final_mssim[0];
        
        cout << "HELLO6-4 " << endl;
        final_mssim = getMSSIM(ORG_mat_Cr, QF_mat_Cr);
        
        cout << "HELLO6-5 " << endl;
        mssim_Cr = final_mssim[0];
        
        
        cout << "HELLO7 " << endl;
    }
    cout << "\n\nDecode " << f2_yuv << " is done!" << endl;
    
    mssim = (6*mssim_Y + mssim_Cb + mssim_Cr)/8;
    psnr  =(6*psnr_Y + psnr_Cb + psnr_Cr)/8;
    
#if S7S_debug >3
    imshow("QF_mat_Y",QF_mat_Y);
    cv::waitKey(0);
    imshow("ORG_mat_Y",ORG_mat_Y);
    cv::waitKey(0);
    printf("# Decoded 8x8 Block#\n");
    cout << std::dec <<  ORG_mat_Y.rowRange(0,1) << " *** "<< QF_mat_Y.rowRange(0,1)<<endl;
    for(int i = 0; i < 8; ++i){
        for(int j = 0; j < 8; ++j){
            cout << int(ORG_mat_Y.at<unsigned char>(i,j)) << " ";
        }
        cout << "\n";
    }
    cout << "\n" <<endl;
    for(int i = 0; i < 8; ++i){
        for(int j = 0; j < 8; ++j){
            cout << int(QF_mat_Y.at<unsigned char>(i,j)) << " ";
        }
        cout << "\n";
    }
#endif
    
    
    
    reportMetrics(psnr_Y, psnr_Cb, psnr_Cr);
    reportMetrics(mssim_Y, mssim_Cb, mssim_Cr);
    
    
    cout<<"mssim: "<<mssim<<endl;
    cout<<"psnr: "<<psnr<<endl;
    
    return 0;
    
}



